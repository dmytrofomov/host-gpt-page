FoodLoop brand kit

Brand guidelines: brand/README.md
Image prompts: brand/prompts.md
Campaign source: brand/campaign.html (serve this directory via python -m http.server)
Ready-to-use files: brand/*.png, brand/*.jpg, brand/*.svg
Original photos: brand/photos/
Web images: img/
Public gallery: https://hostgpt.org/brand/
